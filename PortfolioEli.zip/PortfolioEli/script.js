function filterSelection(category) {
  var i;
  var filterDivs = document.getElementsByClassName("filterDiv");
  if (category == "all") category = "";
  for (i = 0; i < filterDivs.length; i++) {
    removeClass(filterDivs[i], "show");
    if (filterDivs[i].className.indexOf(category) > -1) {
      addClass(filterDivs[i], "show");
    }
  }
}

function addClass(element, name) {
  var arr = element.className.split(" ");
  if (arr.indexOf(name) == -1) {
    element.className += " " + name;
  }
}

function removeClass(element, name) {
  var arr = element.className.split(" ");
  while (arr.indexOf(name) > -1) {
    arr.splice(arr.indexOf(name), 1);
  }
  element.className = arr.join(" ");
}

document.getElementById("allBtn").click();